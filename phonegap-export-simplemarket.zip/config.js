define( function ( require ) {

	"use strict";

	return {
		app_slug : 'simplemarket',
		wp_ws_url : 'http://simplemarket.quickapps-inc.com/wp-appkit-api/simplemarket',
		wp_url : 'http://simplemarket.quickapps-inc.com',
		theme : 'q-android',
		version : '1.0',
		app_title : 'SimpleMarket CI',
		app_platform : 'android',
		gmt_offset : 2,
		debug_mode : 'off',
		auth_key : '93r|f<T1TBe{8Kc8&g&ilM|mjI-Q%o:F7rK#Uh`UuLL=5|!|W}#uAI7orsXMeW#k',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
